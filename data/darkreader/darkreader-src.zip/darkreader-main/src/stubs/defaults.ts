import type {Theme} from '../definitions';

export function extendThemeDefaults(_defaultTheme: Theme): void {
}
