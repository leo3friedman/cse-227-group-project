import {m} from 'malevic';

export function PlusBody(): Malevic.Child {
    return <body></body>;
}
