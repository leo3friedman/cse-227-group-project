export function formatPercent(v: number): string {
    return `${v}%`;
}
