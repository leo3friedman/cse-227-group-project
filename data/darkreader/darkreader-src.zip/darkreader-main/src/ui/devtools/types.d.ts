import type {DevToolsData, ExtWrapper} from '../../definitions';

export type DevtoolsProps = ExtWrapper & {devtools: DevToolsData};
