export enum ThemeEngine {
    cssFilter = 'cssFilter',
    svgFilter = 'svgFilter',
    staticTheme = 'staticTheme',
    dynamicTheme = 'dynamicTheme'
}
