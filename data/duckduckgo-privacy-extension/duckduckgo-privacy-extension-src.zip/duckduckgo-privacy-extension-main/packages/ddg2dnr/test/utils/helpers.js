function emptyBlockList() {
    return {
        cnames: {},
        domains: {},
        entities: {},
        trackers: {},
    };
}

exports.emptyBlockList = emptyBlockList;
