module.exports = {
    Grade: require('./src/classes/grade'),
    Trackers: require('./src/classes/trackers'),
};
