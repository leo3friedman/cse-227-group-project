module.exports = {
    surrogates:
        'google-analytics.com/ga.js application/javascript\n(function() {})();\ngoogle-analytics.com/analytics.js application/javascript\n(function() {})();\n\nfacebook.net/sdk.js application/javascript \n(() => {\n})()',
};
