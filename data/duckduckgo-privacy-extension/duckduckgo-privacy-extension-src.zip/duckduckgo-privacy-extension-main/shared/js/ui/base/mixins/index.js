module.exports = {
    events: require('./events.js'),
    // ...add more here!
};
