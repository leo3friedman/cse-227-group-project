module.exports = {
    setBrowserClassOnBodyTag: require('./set-browser-class.js'),
    parseQueryString: require('./parse-query-string.js'),
};
