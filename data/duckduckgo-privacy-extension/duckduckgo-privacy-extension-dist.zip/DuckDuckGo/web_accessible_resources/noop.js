(() => {
    'use strict';
})();
