### docs/pages/Basic/what-is-githow.md

# what-is-githow

Discover what **Grav** is all about and the core-concepts behind it.
