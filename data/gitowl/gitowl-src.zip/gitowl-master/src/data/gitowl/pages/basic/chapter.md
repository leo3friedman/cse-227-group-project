### Chapter 1

# Basics

Discover what **Grav** is all about and the core-concepts behind it.
