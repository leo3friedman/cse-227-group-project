exports.DefaultActionLogEntityTestFixtures = {
  "id": "5b998a97-29fb-5b1d-86d7-a026867addec",
  "action_log_id": "eebf0a92-18a4-440e-8aa8-799287fc2c26",
  "type": "Resources.created",
  "creator": {
    "id": "f848277c-5398-58f8-a82a-72397af2d450",
    "username": "ada@passbolt.com",
    "profile": {
      "first_name": "Ada",
      "last_name": "Lovelace",
      "avatar": {
        "url": {
          "medium": "img\/public\/Avatar\/22\/47\/85\/50adf80e3534413abdd8e34c9be6d1b6\/50adf80e3534413abdd8e34c9be6d1b6.a99472d5.png",
          "small": "img\/public\/Avatar\/22\/47\/85\/50adf80e3534413abdd8e34c9be6d1b6\/50adf80e3534413abdd8e34c9be6d1b6.65a0ba70.png"
        }
      }
    },
  }
};
