# Insight audits

When adding new insight audits, you can start off by just running `yarn generate-insight-audits`
