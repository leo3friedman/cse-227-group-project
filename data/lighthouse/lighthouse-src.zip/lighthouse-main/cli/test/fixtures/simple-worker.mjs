'use strict';

import './simple-script.js?esm';

console.log('hello from worker!');
