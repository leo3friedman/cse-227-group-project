/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

/* eslint-disable */

document.write('<script src="/perf/level-3.js"></script>');
