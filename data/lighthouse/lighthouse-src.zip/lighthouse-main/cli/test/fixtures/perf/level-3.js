/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

/* eslint-disable */

const dummyDiv = document.createElement('div');
dummyDiv.innerHTML = 'Hello!';

document.body.append(dummyDiv);
