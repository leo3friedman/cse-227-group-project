
self.importScripts('./simple-script.js?importScripts');

console.log('hello from worker!');
