#!/usr/bin/env node
/**
 * @license
 * Copyright 2017 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */

import {begin} from './bin.js';

await begin();
